import java.util.ArrayList;
import java.util.Collections;

public class Spieler {
    ArrayList<Karte> k1 = new ArrayList<>();

    public int Punkte = 0;



    public void setK1(Karte pk1) {
        this.k1.add(pk1);
    }

    public void setPunkte(int punkte) {
        Punkte = Punkte + punkte;
    }

    public int getPunkte() {
        return Punkte;
    }

    public Karte getKarte(int index) {
        return this.k1.get(index);
    }

    public ArrayList<Karte> getList(){
        return k1;

    }

}
