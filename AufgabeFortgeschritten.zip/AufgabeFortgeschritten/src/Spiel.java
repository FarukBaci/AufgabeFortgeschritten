
import javax.swing.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.Scanner;

public class Spiel {

    //Karten werden and Spieler 1 und 2  verte
    static final EnumSet Set2 = EnumSet.allOf(Karte.class);


    Scanner SC = new Scanner(System.in);
    public void Spielen(ArrayList<Karte>k1) {
        Spieler Spieler1 = new Spieler();
        Spieler Spieler2 = new Spieler();
        boolean istDran = true;
        for (int i = 0; i < 18; i++) {
            Spieler1.setK1(k1.get(i));
        }
        for (int x = 18; x < 36; x++) {
            Spieler2.setK1(k1.get(x));

        }
        System.out.println("Spieler 1 bitte Name eingeben");
        String namee = new Scanner(System.in).next();
        if (namee.equalsIgnoreCase("Edona")){
            System.out.println("Du darfst nicht spielen >:(     ");
            System.out.println("Spieler 2 gewinnt!!!!");
            System.err.print("SCHADE EDDYG");
        }else System.out.println("Viel Spaß");
        String namee2 = "";
        if (!namee.equalsIgnoreCase("Edona")) {

            System.out.println("Spieler 2 bitte Name eingeben");
            namee2 = new Scanner(System.in).next();
            if (namee2.equalsIgnoreCase("Edona")) {
                System.out.println("Du darfst nicht spielen >:(     ");
                System.out.println("Spieler 1 gewinnt!!!!");
                System.err.print("SCHADE EDDYG");
            } else System.out.println("Viel Spaß");
        }
        if (!namee.equalsIgnoreCase("Edona") && !namee2.equalsIgnoreCase("Edona")) {
            System.out.println("Herzlich Willkommen zum Auto-Quartett!!!");
            System.out.println(namee + " darf nun beginnen...");

            //Rundenmechanik
            int Spielzug = -1;
            while (Spieler1.getList().size() > 0 && Spieler2.getList().size() > 0) {


                boolean s1 = false;
                boolean s2 = false;
                if (istDran) {
                    Spielzug++;
                    System.out.println("Runde " + Spielzug + ":" + " Spieler 1 ist am Zug.");
                    System.out.println("Dein Auto: " + Spieler1.getKarte(0).name());
                    System.out.print(Spieler1.getKarte(0));

                    boolean korrekt = true; //Flag für erneute Eingabe bei fehlerhafter Eingabe
                    while (korrekt) {
                        String Attribut = SC.next();
                        if (Attribut.equals("p") || Attribut.equals("g") || Attribut.equals("b") || Attribut.equals("l")) {


                            int v = Spieler1.getKarte(0).compareTo(Spieler2.getKarte(0), Attribut);
                            System.out.println(v);
                            Spieler1.setPunkte(v);
                            Spieler2.setPunkte(v * -1);
                            System.out.println("Deine Punktzahl: " + Spieler1.getPunkte());
                            System.out.println("--------------------------------------");
                            switch (v) {
                                case 1:
                                    Spieler1.getList().add(Spieler2.getList().get(0));
                                    Spieler1.getList().addLast(Spieler1.getList().get(0));
                                    Spieler2.getList().remove(0);
                                    Spieler1.getList().remove(0);

                                    break;

                                case -1:
                                    Spieler2.getList().add(Spieler1.getList().get(0));
                                    Spieler2.getList().addLast(Spieler2.getList().get(0));
                                    Spieler1.getList().remove(0);
                                    Spieler2.getList().remove(0);

                                    break;

                                default:
                                    System.out.println("Es gibt keinen Gewinner, Spieler 2 ist dran.");
                                    Spieler1.getList().addLast(Spieler1.getList().get(0));
                                    Spieler2.getList().addLast(Spieler2.getList().get(0));
                                    Spieler1.getList().remove(0);
                                    Spieler2.getList().remove(0);

                            }
                            if (v != 1) istDran = false;
                            korrekt = false;

                        } else {
                            System.out.println("Falsche Eingabe.");
                            System.out.println("Bitte wähle 'p' für PS, 'g' für Gewicht, 'b' für Baujahr und 'l' für Länge.");
                            System.out.println("--------------------------------------");
                        }
                    }

                } else {
                    Spielzug++;
                    System.out.println("Runde " + Spielzug + ":" + " Spieler 2 ist am Zug.");
                    System.out.println("Dein Auto: " + Spieler2.getKarte(0).name());
                    System.out.print(Spieler2.getKarte(0));
                    boolean korrekt = true;
                    while (korrekt) {
                        String Attribut = SC.next();
                        if (Attribut.equals("p") || Attribut.equals("g") || Attribut.equals("b") || Attribut.equals("l")) {
                            int v = Spieler2.getKarte(0).compareTo(Spieler1.getKarte(0), Attribut);
                            System.out.println(v);
                            Spieler2.setPunkte(v);
                            Spieler1.setPunkte(v * -1);
                            System.out.println("Deine Punktzahl: " + Spieler2.getPunkte());
                            System.out.println("--------------------------------------");
                            switch (v) {
                                case 1:
                                    Spieler2.getList().add(Spieler1.getList().get(0));
                                    Spieler2.getList().addLast(Spieler2.getList().get(0));
                                    Spieler1.getList().remove(0);
                                    Spieler2.getList().remove(0);

                                    break;

                                case -1:
                                    Spieler1.getList().add(Spieler2.getList().get(0));
                                    Spieler1.getList().addLast(Spieler1.getList().get(0));
                                    Spieler2.getList().remove(0);
                                    Spieler1.getList().remove(0);

                                    break;

                                default:
                                    System.out.println("Es gibt keinen Gewinner, Spieler1 ist dran.");
                                    Spieler2.getList().addLast(Spieler2.getList().get(0));
                                    Spieler1.getList().addLast(Spieler2.getList().get(0));
                                    Spieler2.getList().remove(0);
                                    Spieler1.getList().remove(0);

                            }
                            if (v != 1) istDran = true;
                            korrekt = false;
                        } else {
                            System.out.println("Falsche Eingabe.");
                            System.out.println("Bitte wähle 'p' für PS, 'g' für Gewicht, 'b' für Baujahr und 'l' für Länge.");
                            System.out.println("--------------------------------------");
                        }
                    }
                }
            }
            if (Spieler1.getList().isEmpty()) {
                System.out.println("Spieler 2 hat gewonnen!");
            } else {

                System.out.println("Spieler 1 hat gewonnen!");
            }
            System.out.println("Hier ist deine Trophäe.");

            String trophyEmoji = "\uD83C\uDFC6";
            System.out.println(trophyEmoji);

        }
    }
    public static void main(String[] args) {
        Spiel spiel1 = new Spiel();
        ArrayList<Karte> k1 = new ArrayList<>(Set2);
        k1 = shuffle(k1);
        spiel1.Spielen(k1);
    }
    public static <Karte> ArrayList shuffle(ArrayList<Karte> list){
        Collections.shuffle(list);
        return list;
    }
}
